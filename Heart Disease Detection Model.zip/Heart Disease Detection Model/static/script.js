document.addEventListener("DOMContentLoaded", function () {
    const resetButton = document.getElementById('resetBtn');
    const predictionText = document.querySelector('h3');

    resetButton.addEventListener("click", function () {
      // Clear all input[type="text"]
      document.querySelectorAll('input[type="text"]').forEach(input => input.value = '');

      // Reset all select dropdowns
      document.querySelectorAll('select').forEach(select => {
        select.selectedIndex = 0;
      });

      // Clear the prediction text
      if (predictionText) {
        predictionText.textContent = '';
      }
    });
  });

