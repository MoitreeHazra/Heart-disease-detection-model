from flask import Flask, render_template, request, redirect, url_for, session
import numpy as np
import joblib

app = Flask(__name__)
app.secret_key = 'your_secure_secret_key'

# Load the trained model
model = joblib.load("heart_disease_model.pkl")

@app.route('/')
def home():
    form_data = session.pop('form_data', {})  # clears after access
    prediction_text = session.pop('prediction_text', "")
    return render_template('index.html', prediction_text=prediction_text, form_data=form_data)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        form_data = {key: request.form[key] for key in request.form}
        values = [float(form_data[key]) for key in form_data]

        data = np.array(values).reshape(1, -1)
        prediction = model.predict(data)[0]
        result = "The person does not have heart disease" if prediction == 0 else "The person has heart disease"
    except Exception as e:
        result = f"Error: {e}"

    session['form_data'] = form_data
    session['prediction_text'] = result
    return redirect(url_for('home') + "#result")

if __name__ == '__main__':
    app.run(debug=True)
